//
//  BaiduMobAdPrerollNativeDelegate.h
//  BaiduMobAdSDK
//
//  Created by lishan04 on 16/10/31.
//  Copyright © 2016年 Baidu Inc. All rights reserved.
//
#import "BaiduMobAdBaseNativeAdDelegate.h"

@protocol BaiduMobAdPrerollNativeDelegate <BaiduMobAdBaseNativeAdDelegate>

@end
