//
//  BaiduMobAdBaseNativeAdView.h
//  BaiduMobAdSDK
//
//  Created by lishan04 on 16/11/4.
//  Copyright © 2016年 Baidu Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaiduMobAdBaseNativeAdView : UIView

@end
